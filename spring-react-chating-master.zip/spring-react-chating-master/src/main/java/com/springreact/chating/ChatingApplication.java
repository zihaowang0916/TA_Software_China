package com.springreact.chating;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChatingApplication {

    public static void main(String[] args) {
        SpringApplication.run(ChatingApplication.class, args);
    }

}
