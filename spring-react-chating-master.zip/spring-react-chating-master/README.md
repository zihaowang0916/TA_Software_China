# spring-react-chating
### Authors: 
@HaofengLiang    @chenk97

### Create Database and User (MySQL)
```
CREATE DATABASE chating;
CREATE USER 'chatuser'@'localhost' IDENTIFIED BY 'wealllovechat';
GRANT ALL ON chating.* TO 'chatuser'@'localhost';
```
